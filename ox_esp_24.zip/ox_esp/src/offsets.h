// Oxide: Survival Island (obfuscated build: re-dump + update after every game patch).
// Re-derived field-by-field from dump.csALABYBA (uploaded today, modified Oct 31 -- the actual current
// install, confirmed by file recency over every other dump sitting around). The previous edit in this file
// used dump_1.16.11978.zip by mistake (that's literally its filename) -- a stale, older dump whose
// PlayerManager layout predates the parachuteConfig field. ALABYBA's PlayerManager (TypeDefIndex: 10206)
// DOES have parachuteConfig at the front (0x68), which is the shift this file had originally, before that
// bad edit. Confirmed line by line again against dump.csALABYBA so this doesn't flip a third time blind.
#pragma once
#include <cstdint>

struct ClassRef { const char* ns; const char* name; uint64_t typeinfo_rva; };

namespace off {
namespace PlayerManager {            // class Oxide.PlayerManager : NetworkBehaviour
  constexpr ClassRef cls = {"Oxide", "PlayerManager", 0};
  constexpr uint32_t netIdentity = 0x40;          // NetworkBehaviour.<netIdentity>k__BackingField -- base class, unaffected
  constexpr uint32_t fpManager = 0xD0;            // public FPManager fpManager; // 0xD0
  constexpr uint32_t vitals = 0x108;              // public PlayerVitals vitals; // 0x108
  constexpr uint32_t s_clientPlayerList = 0x10;   // static List<PlayerManager>
  constexpr uint32_t s_activePlayerList = 0x8;
  constexpr uint32_t mouseLook = 0xB0;            // public MouseLook mouseLook; // 0xB0
  constexpr uint32_t lookAngle = 0x208;           // public float lookAngle; // 0x208
  constexpr uint32_t kccReference = 0xF0;         // InterfaceReference<ta> kccReference; // 0xF0 -- _component at +0x10
  constexpr uint32_t lastTickPosition = 0x228;    // public Vector3 lastTickPosition; // 0x228
  constexpr uint32_t lastSavedPosition = 0x234;   // public Vector3 lastSavedPosition; // 0x234
  constexpr uint32_t nicklabel = 0x170;           // public ZJ nicklabel; // 0x170
}
namespace NetworkIdentity { constexpr uint32_t isLocalPlayer = 0x4A; }   // confirmed in ALABYBA: <isLocalPlayer>k__BackingField // 0x4A
namespace FPManager { constexpr ClassRef cls = {"Oxide", "FPManager", 0}; constexpr uint32_t m_WorldCamera = 0x20; }   // confirmed in ALABYBA: public Camera m_WorldCamera; // 0x20
namespace FPHitscan {
  constexpr ClassRef cls = {"Oxide", "FPHitscan", 0};
  // ALABYBA: exactly ONE private void X(Ray x) in FPHitscan -- "emP". No ambiguity this time, confirmed
  // by grepping the whole class body, not assumed from an older dump.
  constexpr const char* fireCandidates[] = {"emP"};
  constexpr int fireCandidateCount = 1;
}
namespace Vitals {                   // GenericVitals/kAg: Entity (kAH) at 0x68; kAH.Health (reactive float) 0x98, DisplayName 0x88
  constexpr uint32_t Entity = 0x68;
  constexpr uint32_t m_MaxHealth = 0x88;
  constexpr uint32_t E_DisplayName = 0x88;
  constexpr uint32_t E_Health = 0x98;
  constexpr uint32_t E_Velocity = 0xB0;
}
}
